#!/bin/bash
echo "[INIT] Running init.sh — system hardening placeholder"
# Here you can add firewall rules, sysctl tweaks, or security patches
